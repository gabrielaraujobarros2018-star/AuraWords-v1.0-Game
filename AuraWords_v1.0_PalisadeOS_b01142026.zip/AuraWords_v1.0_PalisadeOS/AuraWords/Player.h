#pragma once
#include <string>

class Player {
public:
    Player();

    void moveLeft();
    void moveRight();

    void addPositive();
    void addNegative();

    int totalAura() const;

    float x() const;
    float y() const;
    float radius() const;

    void save();
    void load();

private:
    float posX;
    float posY;
    int positiveAura;
    int negativeAura;
};