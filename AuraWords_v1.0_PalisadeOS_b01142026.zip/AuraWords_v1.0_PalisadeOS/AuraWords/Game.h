#pragma once
#include <vector>
#include "Player.h"
#include "Word.h"

class Game {
public:
    Game();
    void initialize();
    void run();
    void shutdown();

private:
    Player player;
    std::vector<Word> words;
    bool running;

    void update();
    void spawnWords();
    void checkWinCondition();
};