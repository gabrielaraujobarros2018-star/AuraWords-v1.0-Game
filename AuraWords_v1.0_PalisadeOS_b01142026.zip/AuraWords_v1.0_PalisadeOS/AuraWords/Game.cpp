#include "Game.h"
#include "Renderer.h"
#include "Input.h"
#include <chrono>
#include <thread>

Game::Game() : running(true) {}

void Game::initialize() {
    player.load();
    spawnWords();
}

void Game::run() {
    while (running) {
        Input::poll(player);
        update();
        Renderer::draw(player, words);
        checkWinCondition();
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }
}

void Game::shutdown() {
    player.save();
}

void Game::spawnWords() {
    static const char* positive[12] = {
        "Hope","Joy","Peace","Trust","Love","Focus",
        "Calm","Strength","Growth","Light","Faith","Clarity"
    };

    static const char* negative[12] = {
        "Fear","Anger","Doubt","Stress","Hate","Chaos",
        "Guilt","Pain","Noise","Loss","Shadow","Rage"
    };

    for (int i = 0; i < 12; ++i) {
        words.emplace_back(positive[i], true);
        words.emplace_back(negative[i], false);
    }
}

void Game::update() {
    for (auto& w : words) {
        w.update();

        if (w.checkCollision(player)) {
            if (w.isPositive()) {
                player.addPositive();
                w.consume();
            } else {
                if (w.hit()) {
                    w.consume();
                } else {
                    player.addNegative();
                }
            }
        }
    }
}

void Game::checkWinCondition() {
    if (player.totalAura() >= 100) {
        running = false;
    }
}