#pragma once
#include "Player.h"

class Input {
public:
    static void poll(Player& p);
};