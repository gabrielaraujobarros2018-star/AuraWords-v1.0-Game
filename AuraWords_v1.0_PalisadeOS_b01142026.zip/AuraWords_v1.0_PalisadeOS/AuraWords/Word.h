#pragma once
#include <string>
#include "Player.h"

class Word {
public:
    Word(const std::string& text, bool positive);

    void update();
    bool checkCollision(const Player& p);
    bool hit();
    void consume();

    bool isPositive() const;
    bool active() const;

private:
    std::string value;
    float posX;
    float posY;
    int hits;
    bool positiveType;
    bool alive;
};