#pragma once
#include <vector>
#include "Player.h"
#include "Word.h"

class Renderer {
public:
    static void draw(const Player& p, const std::vector<Word>& words);
};