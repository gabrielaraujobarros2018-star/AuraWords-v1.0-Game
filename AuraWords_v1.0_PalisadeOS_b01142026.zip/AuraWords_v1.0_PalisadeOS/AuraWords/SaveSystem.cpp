#include <fstream>
#include <string>

void saveValue(const std::string& key, int value) {
    std::ofstream f(key + ".dat", std::ios::binary);
    f.write((char*)&value, sizeof(int));
}

int loadValue(const std::string& key) {
    int v = 0;
    std::ifstream f(key + ".dat", std::ios::binary);
    if (f.good()) f.read((char*)&v, sizeof(int));
    return v;
}