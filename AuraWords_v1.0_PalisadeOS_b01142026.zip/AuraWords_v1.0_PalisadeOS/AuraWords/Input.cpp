#include "Input.h"
#include <conio.h>

void Input::poll(Player& p) {
    if (!_kbhit()) return;

    char c = _getch();
    if (c == 'a') p.moveLeft();
    if (c == 'd') p.moveRight();
}