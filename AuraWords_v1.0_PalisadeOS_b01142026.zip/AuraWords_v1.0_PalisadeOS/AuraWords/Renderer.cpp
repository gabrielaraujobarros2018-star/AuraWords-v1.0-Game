#include "Renderer.h"
#include <iostream>

void Renderer::draw(const Player& p, const std::vector<Word>& words) {
    system("clear"); // white background implied

    std::cout << "Aura Words\n";
    std::cout << "Aura: " << p.totalAura() << "\n";
    std::cout << "Player at X: " << p.x() << "\n";

    for (const auto& w : words) {
        if (w.active()) {
            std::cout << "Word moving...\n";
        }
    }
}