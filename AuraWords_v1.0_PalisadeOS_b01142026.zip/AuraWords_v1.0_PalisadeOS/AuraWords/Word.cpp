#include "Word.h"
#include <cmath>

Word::Word(const std::string& text, bool positive)
    : value(text), positiveType(positive) {
    posX = 800.0f;
    posY = 100.0f + (rand() % 400);
    hits = 0;
    alive = true;
}

void Word::update() {
    if (!alive) return;
    posX -= 2.5f;
}

bool Word::checkCollision(const Player& p) {
    if (!alive) return false;
    float dx = posX - p.x();
    float dy = posY - p.y();
    return std::sqrt(dx*dx + dy*dy) < p.radius();
}

bool Word::hit() {
    hits++;
    return hits >= 2;
}

void Word::consume() {
    alive = false;
}

bool Word::isPositive() const {
    return positiveType;
}

bool Word::active() const {
    return alive;
}