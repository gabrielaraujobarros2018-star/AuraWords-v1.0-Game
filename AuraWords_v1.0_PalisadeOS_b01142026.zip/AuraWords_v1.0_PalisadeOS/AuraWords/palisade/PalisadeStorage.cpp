#include <fstream>
#include <string>

namespace PalisadeOS {

static std::string BaseStoragePath() {
    return "/palisade/os/userdata/adminApps/AuraWords/";
}

static std::string ResolvePath(const std::string& file) {
    return BaseStoragePath() + file;
}

bool WritePersistent(const std::string& name, int value) {
    std::ofstream f(
        ResolvePath(name),
        std::ios::binary | std::ios::out
    );
    if (!f.good()) return false;
    f.write((char*)&value, sizeof(int));
    return true;
}

bool ReadPersistent(const std::string& name, int& out) {
    std::ifstream f(
        ResolvePath(name),
        std::ios::binary | std::ios::in
    );
    if (!f.good()) return false;
    f.read((char*)&out, sizeof(int));
    return true;
}

bool StorageReady() {
    int test = 42;
    WritePersistent("test.dat", test);
    int read = 0;
    return ReadPersistent("test.dat", read) && read == 42;
}

static bool ready = StorageReady();

}