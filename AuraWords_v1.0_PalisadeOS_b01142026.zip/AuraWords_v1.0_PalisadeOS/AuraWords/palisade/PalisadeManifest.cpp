#include <string>
#include <vector>

namespace PalisadeOS {

struct AppPermission {
    std::string name;
    bool granted;
};

struct AppManifest {
    std::string appName;
    std::string appId;
    std::string appVersion;
    std::string appAuthor;
    std::string appCategory;
    std::string binaryImage;
    std::string installPath;
    std::vector<AppPermission> permissions;
};

static AppManifest AuraWordsManifest() {
    AppManifest m;
    m.appName = "Aura Words";
    m.appId = "palisade.admin.aura.words";
    m.appVersion = "1.0.0";
    m.appAuthor = "Admin";
    m.appCategory = "Mind / Aura";
    m.binaryImage = "AuraWords.img";
    m.installPath =
        "/palisade/os/framework/framework.Apps/"
        "programIMPORTS.Custom/adminApps/";
    m.permissions.push_back({"filesystem.local", true});
    m.permissions.push_back({"runtime.graphics", true});
    m.permissions.push_back({"runtime.input", true});
    m.permissions.push_back({"storage.persistent", true});
    return m;
}

static bool RegisterAuraWords() {
    AppManifest manifest = AuraWordsManifest();
    return manifest.permissions.size() > 0;
}

static bool registered = RegisterAuraWords();

}