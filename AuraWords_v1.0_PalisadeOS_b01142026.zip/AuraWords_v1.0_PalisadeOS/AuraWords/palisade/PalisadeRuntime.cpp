#include <iostream>
#include <atomic>

namespace PalisadeOS {

enum RuntimeState {
    INIT,
    RUNNING,
    PAUSED,
    SHUTDOWN
};

static std::atomic<RuntimeState> state;

void RuntimeInit() {
    state.store(INIT);
}

void RuntimeStart() {
    state.store(RUNNING);
}

void RuntimePause() {
    state.store(PAUSED);
}

void RuntimeResume() {
    state.store(RUNNING);
}

void RuntimeShutdown() {
    state.store(SHUTDOWN);
}

bool RuntimeIsActive() {
    return state.load() == RUNNING;
}

void RuntimeTick() {
    if (state.load() == RUNNING) {
        // Game loop allowed
    }
}

void RuntimeDispatch() {
    switch (state.load()) {
        case INIT:
            RuntimeStart();
            break;
        case RUNNING:
            RuntimeTick();
            break;
        case PAUSED:
            break;
        case SHUTDOWN:
            break;
    }
}

struct RuntimeAutoInit {
    RuntimeAutoInit() { RuntimeInit(); }
};

static RuntimeAutoInit autoInit;

}