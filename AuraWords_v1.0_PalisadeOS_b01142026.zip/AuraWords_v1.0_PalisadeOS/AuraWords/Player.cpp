#include "Player.h"
#include <fstream>

Player::Player() {
    posX = 400.0f;
    posY = 550.0f;
    positiveAura = 0;
    negativeAura = 0;
}

void Player::moveLeft() { posX -= 5.0f; }
void Player::moveRight() { posX += 5.0f; }

void Player::addPositive() { positiveAura += 20; }
void Player::addNegative() { negativeAura += 20; }

int Player::totalAura() const {
    return positiveAura - negativeAura;
}

float Player::x() const { return posX; }
float Player::y() const { return posY; }
float Player::radius() const { return 30.0f; }

void Player::save() {
    std::ofstream f("aura.save", std::ios::binary);
    f.write((char*)&positiveAura, sizeof(int));
    f.write((char*)&negativeAura, sizeof(int));
}

void Player::load() {
    std::ifstream f("aura.save", std::ios::binary);
    if (f.good()) {
        f.read((char*)&positiveAura, sizeof(int));
        f.read((char*)&negativeAura, sizeof(int));
    }
}