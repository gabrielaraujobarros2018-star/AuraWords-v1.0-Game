# AuraWords building tips

## Compilation "AuraWords"

Example build pipeline:

```
g++ *.cpp -O2 -static -o AuraWords.img
```

Then move:

```
mv AuraWords.img \
/palisade/os/framework/framework.Apps/programIMPORTS.Custom/adminApps/
```

## Why the design works:

- Extremely small tree
- No external dependencies
- Deterministic logic
- System-friendly (fits PalisadeOS philosophy)
- Expandable later without refactor
- Emotion-driven gameplay without complexity

## Next

When you want:
- a .palisade descriptor
- icon / signature hooks
- app permissions UI exposure
- or converting this into a system-bundled app
